export class productType{
    productTypeId!: number;
    name!: string;
}