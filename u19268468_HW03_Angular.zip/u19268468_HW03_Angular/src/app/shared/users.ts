export class user {
    emailaddress: string = "";
    password: string = "";
}