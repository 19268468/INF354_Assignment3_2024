export class brands{
    brandId!: number;
    name!: string;
}